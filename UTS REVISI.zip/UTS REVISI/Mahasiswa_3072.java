/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.uts3_3072;

/**
 *
 * @author fatur
 */
public class Mahasiswa_3072 {
    protected String nim, nama, jurusan;
    protected int ipk;
    
    public void tampilDataMhs(){
        System.out.println("NIM : "+nim);
        System.out.println("Nama : "+ nama);
        System.out.println("Jurusan : "+ jurusan);
        System.out.println("IPK : "+ ipk);
    }
    
}
